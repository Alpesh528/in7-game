# IN7 Game Information Website

A simple responsive static website for GitHub Pages.

## Files
- `index.html` — homepage article
- `about.html` — About Us
- `privacy-policy.html` — Privacy Policy
- `disclaimer.html` — Disclaimer
- `contact.html` — Contact Us
- `style.css` — shared responsive styling

## Before publishing
1. Replace `[your-email@example.com]` in `contact.html` and `privacy-policy.html` with your real contact email.
2. Review every statement and update it to match the actual service and your site's practices.
3. Do not describe this site as official unless you are authorized to do so.
4. Upload all files to the root of your GitHub repository.
5. In GitHub, open **Settings → Pages**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish and open the URL shown in the Pages section.

This is a static informational template. It does not include app downloads, account registration, payment processing, analytics or a working contact form.
